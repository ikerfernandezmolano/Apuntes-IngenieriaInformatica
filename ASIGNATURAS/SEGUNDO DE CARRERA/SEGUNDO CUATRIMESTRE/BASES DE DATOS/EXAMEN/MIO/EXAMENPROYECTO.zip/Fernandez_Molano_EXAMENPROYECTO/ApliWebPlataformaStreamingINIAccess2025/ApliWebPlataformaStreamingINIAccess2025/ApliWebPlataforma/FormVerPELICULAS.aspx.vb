﻿Imports System.Data.OleDb 'Para las conexiones tipo OleDb -- ACCESS
Public Class FormVerPELICULAS
    Inherits System.Web.UI.Page
    'Asigna a Usuario el LoginName actual pasado a minúsculas (para las comparaciones)
    Dim usuario As String = StrConv(System.Web.HttpContext.Current.User.Identity.Name, VbStrConv.Lowercase)
    'Indicamos la cadena de conexion (tipo OLEDB)
    Dim cadenaConexion As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\TEMP\Base de Datos de Access 2002-2003.mdb"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conexion As OleDb.OleDbConnection
        Dim transaccion As OleDbTransaction

        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()

        transaccion = conexion.BeginTransaction()

        Try
            Dim instruccionSQL As String
            Dim dbComm As OleDbCommand

            instruccionSQL = "SELECT codigo FROM PELICULA WHERE titulo=?"
            dbComm = New OleDbCommand(instruccionSQL, conexion, transaccion)
            dbComm.Parameters.Add(New OleDbParameter("param1", OleDbType.VarChar)).Value = Me.tituloPeli.Text
            Dim codigoPeli As Double = dbComm.ExecuteScalar()

            instruccionSQL = "DELETE FROM ETIQUETA WHERE movieId=? AND etiqueta=?"
            dbComm = New OleDbCommand(instruccionSQL, conexion, transaccion)
            dbComm.Parameters.Add(New OleDbParameter("param1", OleDbType.Double)).Value = codigoPeli
            dbComm.Parameters.Add(New OleDbParameter("param2", OleDbType.VarChar)).Value = Me.etiquetaPeli.Text
            dbComm.ExecuteNonQuery()

            instruccionSQL = "INSERT INTO ETIQUETA VALUES(?,?)"
            dbComm = New OleDbCommand(instruccionSQL, conexion, transaccion)
            dbComm.Parameters.Add(New OleDbParameter("param1", OleDbType.Double)).Value = codigoPeli
            dbComm.Parameters.Add(New OleDbParameter("param2", OleDbType.VarChar)).Value = Me.etiquetaPeli.Text
            dbComm.ExecuteNonQuery()

            instruccionSQL = "SELECT COUNT(*) FROM ETIQUETA WHERE movieId=? AND etiqueta=?"
            dbComm = New OleDbCommand(instruccionSQL, conexion, transaccion)
            dbComm.Parameters.Add(New OleDbParameter("param1", OleDbType.Double)).Value = codigoPeli
            dbComm.Parameters.Add(New OleDbParameter("param2", OleDbType.VarChar)).Value = Me.etiquetaPeli.Text
            Dim correcto As Double = dbComm.ExecuteScalar()

            If correcto = 1 Then
                MsgBox("Borradas las repeticiones de la etiqueta " + Me.etiquetaPeli.Text + " en la película código " + codigoPeli.ToString() + " .")
                transaccion.Commit()
            Else
                MsgBox("La etiqueta no se ha añadido correctamente.")
                transaccion.Rollback()
            End If
        Catch ex As Exception
            MsgBox("Algo ha ido mal: " + ex.Message)
            transaccion.Rollback()
        Finally
            conexion.Close()
            conexion.Dispose()
        End Try
    End Sub
End Class