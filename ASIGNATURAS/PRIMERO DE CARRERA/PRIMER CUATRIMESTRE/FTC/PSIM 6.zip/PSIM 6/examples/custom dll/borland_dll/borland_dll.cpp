// This is a sample C++ program for Borland C++ (Version 5.0 and later).
// The generated DLL is to be linked to PSIM.

// To compile the program into DLL, you can open the project file "borland_dll.ide" as
// provided. Or you can create a new project by following the procedure below:

//    - Create a directory called "C:\borland_dll", and copy the file "borland_dll.cpp"
//      that comes with the PSIM software into the directory C:\borland_dll.

//    - Start Borland C++. From the "File" menu, choose "New"/"Project". Set the
//      project name as "C:\borland_dll\borland_dll.ide", the Target Type as
//      "Dynamic Library [.dll]", the Platform as "Win32", and select "Static" link.

//      - From the "Project" window, delete the files "borland_dll.def" and "borland_dll.rc".

//      - Make sure that, in the "Option" menu, under "Project"/"32-bit Compilers"/
//        "Calling Convention", calling convention "C" is selected.

//      - Add your own code as needed.

//      - From the "Project" menu, choose "Build All".
//
//      - Give a unique name to the DLL file. For example, if your schematic file is called
//        "test borland_dll.sch", you may wish to call it "test_fortran_dll.dll".
//
//      - Copy the renamed DLL file into the same directory as the schematic file.
//        In the circuit, specify the external DLL block file name as the one you specified
//        (for example, "test_fortran_dll.dll" in this case). You are then ready to run
//        PSIM with your own DLL.

// This sample program multiplies the input array in[0:2] by 5, and stores
// the output in out[0:2].

// Do not change the following line.
// You may change the variable names (say from "t" to "Time").
// But DO NOT change the function name, number of variables,
// variable type, and sequence.

// Variables:
//      t: Time, passed from PSIM by value
//   delt: Time step, passed from PSIM by value
//     in: input array, passed from PSIM by reference
//    out: output array, sent back to PSIM (Note: the values of out[*] can
//         be modified in PSIM)

// The maximum length of the input and output array "in" and "out" is 30.

void __declspec(dllexport) simuser (double t, double delt, double *in, double *out)

{
//Place your code here............begin

	int i;

	for (i=0; i<3; i++)
	{
		out[i] = in[i]*5.;
	}

//Place your code here............end
}

