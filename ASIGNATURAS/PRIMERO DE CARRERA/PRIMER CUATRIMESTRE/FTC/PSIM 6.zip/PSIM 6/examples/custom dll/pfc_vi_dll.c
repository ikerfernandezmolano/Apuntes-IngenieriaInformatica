// This is a sample C program for Microsoft C/C++ 5.0 or 6.0.
// The generated DLL is to be linked to PSIM.

// To compile the program into DLL, follow the procedure below:

//    - Create a directory called "C:\pfc_vi_dll", and copy the file "pfc_vi_dll.c"
//      that comes with the PSIM software into the directory C:\pfc_vi_dll.
//
//    - Start Visual C++. From the "File" menu, choose "New". In the "Projects" 
//      page, select "Win32 Dynamic-Link Library", and set "Project name" as 
//      "ms_user0", and "Location" as "C:\pfc_vi_dll". Make sure that 
//      "Create new workspace" is selected, and "Win32" is selected under 
//      "Platform", 
//      . 
//
//    - [for Version 6.0] When asked "What kind of DLL would you like to create?", 
//      select "An empty DLL project.". 
//
//    - From the "Project" menu, go to "Add to Project"/"Files...", and select
//      "pfc_vi_dll.c".
//
//    - From the "Build" menu, go to "Set Active Configurations...", and select
//      "Win32 Release". From the "Build" menu, choose "Rebuild All" to generate 
//      the DLL file "pfc_vi_dll.dll". The DLL file will be stored under the 
//      directory "C:\pfc_vi_dll\release".
//
//    - Copy the file "pfc_vi_dll" into the same directory as the schematic file. 
//      In the circuit, specify the external DLL block file name as 
//      "pfc_vi_dll.dll". You are then ready to run PSIM with your own DLL.

// This sample program calculates the rms of a 60-Hz input in[0], and
// stores the output in out[0].

// Activate (enable) the following line if the file is a C++ file (i.e. "msvc_dll.cpp")
//extern "C"

// You may change the variable names (say from "t" to "Time").
// But DO NOT change the function name, number of variables,	variable type, and sequence.

// Variables:
//      t: Time, passed from PSIM by value
//   delt: Time step, passed from PSIM by value
//     in: input array, passed from PSIM by reference
//    out: output array, sent back to PSIM (Note: the values of out[*] can
//         be modified in PSIM)

// The maximum length of the input and output array "in" and "out" is 20.

// Warning: Global variables above the function ms_user0 (t,delt,in,out)
//          are not allowed!!!

#include <math.h>

__declspec(dllexport) void simuser (t, delt, in, out)

// Note that all the variables must be defined as "double"
double t, delt;
double *in, *out;

{
// Place your code here............begin

	double Voref=10.5, Vcarr=10., Va, iL, Vo, Vm;
	double errv, erri, Ts=33.33e-6;
	static double yv=0., yi=0., uv=0., ui=0., iref;
	static int count=0, Ncount, flagSample=1, npulse, npulse_next=0, gating;

// Calculate the no. of counts in one period
	Ncount=Ts/delt;

// Check if the counter reaches the end of the period. If yes,
// set the sampling flag to 1. 
	if (count == Ncount)
	{
		flagSample=1;
//      Reset the counter to 0.
		count=0;
//      Update the on-time pulse width
		npulse=npulse_next;
	}

// If the sampling flag is 1, sample the inputs and calculate the
// on-time pulse width npulse.
	if (flagSample == 1)
	{
//		Reset the sampling flag
		flagSample=0;

//		Sample the inputs
		Va=fabs(in[0]);
		iL=in[1];
		Vo=in[2];

//		Calculate the outer loop PI controller using Trapezoidal Rule
		errv=Voref-Vo;
		yv=yv+(33.33*errv+uv)*Ts/2.;

		iref=(errv+yv)*Va;

//		Calculate the inner loop PI controller
		erri=iref-iL;
		yi=yi+(3400.*erri+ui)*Ts/2.;

		Vm=yi+0.3*erri;

//		Calculate the on-time pulse width.
//      Note that this value is not used within this sampling period, but 
//      is used at the beginning of the next sampling period.
		npulse_next=Ncount * (Vm/Vcarr);

//		Store old values
		uv=33.33*errv;
		ui=3400.*erri;

	}

// Generate the switch gating signal
	if (count <= npulse )
	{gating=1;}
	else
	{gating=0;}

// Output
	out[0]=gating;
	out[1]=iref;
	out[2]=npulse;

// Note: Among the 3 output variables, "gating" is calculated at
// every time step, but "iref" and "npulse" are calculated only
// once in one sampling period. Both "gating" and "iref" can be
// defined as either static or non-static. 
	
// But if "iref" is defined as non-static, its value will be zero at 
// the points other than the sampling point. In order to see the 
// value at the sampling point, the print step Iprint in the simulation
// control in SIMCAD must be set to 1. Otherwise the sampling point 
// may be skipped, resulting in a waveform of all zero.


// The variable "npulse" must be declared as static as its
// value is used at every time step and must be retained.


// Increment the counter by 1
	count++;

// Place your code here............end
}
