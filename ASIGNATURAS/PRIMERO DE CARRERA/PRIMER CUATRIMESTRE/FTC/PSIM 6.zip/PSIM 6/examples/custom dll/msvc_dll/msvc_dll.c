// This is a sample C program for Microsoft C/C++ 5.0 or 6.0.
// The generated DLL is to be linked to PSIM.

// To compile the program into DLL, you can open the workspace file "msvc_dll.dsw" 
// as provided. Or you can create a new project by following the procedure below:

//    - Create a directory called "C:\msvc_dll", and copy the file "msvc_dll.c"
//      that comes with the PSIM software into the directory C:\msvc_dll.
//
//    - Start Visual C++. From the "File" menu, choose "New". In the "Projects" 
//      page, select "Win32 Dynamic-Link Library", and set "Project name" as 
//      "ms_user0", and "Location" as "C:\msvc_dll". Make sure that 
//      "Create new workspace" is selected, and "Win32" is selected under 
//      "Platform", 
//      . 
//
//    - [for Version 6.0] When asked "What kind of DLL would you like to create?", 
//      select "An empty DLL project.". 
//
//    - From the "Project" menu, go to "Add to Project"/"Files...", and select
//      "msvc_dll.c".
//
//    - Add your own code as needed.
//
//    - From the "Build" menu, go to "Set Active Configurations...", and select
//      "Win32 Release". From the "Build" menu, choose "Rebuild All" to generate 
//      the DLL file "msvc_dll.dll". The DLL file will be stored under the 
//      directory "C:\msvc_dll\release".
//
//    - Give a unique name to the DLL file. For example, if your schematic file 
//      is called "test msvc_dll.sch", you can call it "test_msvc_dll.dll".
//
//    - Copy the renamed DLL file into the same directory as the schematic file. 
//      In the circuit, specify the external DLL block file name as the one 
//      you specified (for example, "test_msvc_dll.dll" in this case). You are 
//      then ready to run PSIM with your own DLL.

// This sample program calculates the rms of a 60-Hz input in[0], and
// stores the output in out[0].

// Activate (enable) the following line if the file is a C++ file (i.e. "msvc_dll.cpp")
//extern "C"

// You may change the variable names (say from "t" to "Time").
// But DO NOT change the function name, number of variables,	variable type, and sequence.

// Variables:
//      t: Time, passed from PSIM by value
//   delt: Time step, passed from PSIM by value
//     in: input array, passed from PSIM by reference
//    out: output array, sent back to PSIM (Note: the values of out[*] can
//         be modified in PSIM)

// The maximum length of the input and output array "in" and "out" is 30.

// Warning: Global variables above the function ms_user0 (t,delt,in,out)
//          are not allowed!!!

#include <math.h>

__declspec(dllexport) void simuser (t, delt, in, out)

// Note that all the variables must be defined as "double"
double t, delt;
double *in, *out;

{
// Place your code here............begin

//  Define "sum" as "static" in order to retain its value.
	static double nsum=0., sum=0., rms;
	double Tperiod;

	Tperiod=1./60.;

	if (t >= nsum*Tperiod)
	{
		nsum=nsum+1.;
		rms = sqrt(sum*delt/Tperiod);
		sum=0.;
	}

	out[0] = rms;
	sum=sum+in[0]*in[0];

// Place your code here............end
}
