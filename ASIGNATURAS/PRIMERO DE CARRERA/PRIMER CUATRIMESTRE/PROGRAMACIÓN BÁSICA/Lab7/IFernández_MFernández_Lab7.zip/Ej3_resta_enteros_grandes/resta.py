def escribir_entero_grande(E):
#Este subprograma escribira por pantalla los digitos almacenados en E
# de izda a drcha y sin mostrar los ceros a la izda
# Ej.     0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#         0, 0, 0, 9, 9, 9, 9, 9, 9, 9,
#         9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
#         9, 9, 9, 9, 9, 9, 9, 9, 9, 9
# Deberia de imprimir 999999999999999999999999999
    pos=0
    while pos<len(E) and E[pos]==0: 
        pos=pos+1
    if pos==len(E):
       print("0",end="")
    for X in range(pos,len(E)):
        print(E[X],end="")

   
def mayor(E1,E2):
# Pre: E1 y E2 son mayores o iguales que cero
#      len(E1) = len(E2)
# Post: el resultado es true si E1 > E2 y False si no
# NOTA: Aunque python permite comparar directamente dos vectores, para este
#       ejercicio se pide expresamente que el resultado se calcule comparando
#       DIGITO A DIGITO los valores representados por E1 y E2
    E1_mayor_E2=True
    encontrado_mayor=False
    pos=0
    while not encontrado_mayor and pos<len(E1):
        if E1[pos]<E2[pos]:
            E1_mayor_E2=False
            encontrado_mayor=True
        elif E1[pos]==E2[pos]:
            pos=pos+1   
        elif E1[pos]>E2[pos]:
            encontrado_mayor=True
    return E1_mayor_E2
   
   
def resta(E1,E2):
#Pre: E1 y E2 tienen ceros en las cifras no ocupadas más significativas 
#                                                    (más a la izquierda)
#      E1 y E2 son mayores o iguales que cero
#      len(E1) = len(E2)
#Post: si E2 > E1 entonces el resultado es cero
#      si no el resultado es la resta de los dos valores de entrada, E1 - E2
    rdo=[0]*len(E1)
    if mayor(E1,E2):
        for Ind in reversed(range(len(E1))):
            rdo[Ind]=rdo[Ind]+E1[Ind]-E2[Ind]
            if rdo[Ind]<0:
                rdo[Ind]=rdo[Ind]+10
                rdo[Ind-1]=-1
    return rdo
   
   
    
def prueba():
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 8, 8, 8, 1, 2, 3, 5, 5, 5)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 4, 4, 4, 1, 2, 3, 5, 5, 5)
    print("Primera prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 444000000 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")

    
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 9, 9, 9, 9, 9, 9, 9,
         9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
         9, 9, 9, 9, 9, 9, 9, 9, 9, 9)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    print("Segunda prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 999999999999999999999999998 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)    
    print("Tercera prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 99899999999999999999999999999 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7)   
    print("Cuarta prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 99899999944444444444444444445 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 9, 9, 9, 0, 0, 0, 0, 0, 0,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 2)
    print("Quinta prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 0 (dado que N2 > N1 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    N2= (0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)    

    print("Sexta prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 0 (dado que N2 > N1 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")

    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 2)
    print("Septima prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 0 (dado que N2 > N1 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    print("Octava prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 1 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    N2= (1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    print("Novena prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 0 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
    N1= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    N2= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    print("Decima prueba.")
    print("==============")
    escribir_entero_grande(N1)
    print(" menos ", end="")
    escribir_entero_grande(N2)
    print("\n")
    print("El resultado debe ser 0 y es: ")
    escribir_entero_grande(resta(N1, N2))
    print("\n")
    
prueba()
