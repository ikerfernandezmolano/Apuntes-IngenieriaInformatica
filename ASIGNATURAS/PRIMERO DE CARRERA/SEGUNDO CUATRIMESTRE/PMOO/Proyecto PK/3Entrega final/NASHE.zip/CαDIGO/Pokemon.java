package org.pmoo.packproyecto;

public abstract class Pokemon {
	private String nombre;
	private String tipo;
	private int vida;
	private ListaAtaque listaAtaques=new ListaAtaque();
	
	public Pokemon(String pNombre,String pTipo, int pVida) {
		this.nombre=pNombre;
		this.tipo=pTipo;
		this.vida=pVida;
		this.listaAtaques=crearListaAtaques();
	}
	
	public void imprimir() {
		System.out.println("\nNOMBRE : " + this.nombre + ", VIDA : " + this.vida +", TIPO : " + this.tipo);
		this.listaAtaques.imprimir();
	}
	
	private int usarAtaque(int pPosAtaqueEnLista) {
		return this.listaAtaques.usarAtaque(pPosAtaqueEnLista);
	} 
	
	public void cambiarVida(int pDa�o) {
		this.vida=this.vida-pDa�o;
	}
	
	public boolean muerto() {
		boolean muerto=false;
		if(this.vida<=0) {
			muerto=true;
		}
		return muerto;
	}
	
	public void atacar(Pokemon pPK) throws CambiarDePokemonException,UsarCuraException{
		int num=0;
		boolean repetir=true;
		int da�o=0;
		while(num==0||repetir) {
			num=Teclado.getTeclado().leerNumero(6);
			if(num==5) {
				throw(new CambiarDePokemonException());
			}
			else if(num==6) {
				throw(new UsarCuraException());
			}
			da�o=this.usarAtaque(num-1);
			if((num<1&&num>4)||da�o==-100000) {
				System.out.println("ERROR: Su respuesta no es la esperada.");
				System.out.println("�VUELVE A INTENTARLO!");
			}
			else{
				repetir=false;
			}	
		}
		if(this.supereficaz(pPK)) {
			da�o=da�o+(da�o/5);
			System.out.println("Tu ataque es SUPEREFICAZ");
		}
		else if(this.pocoeficaz(pPK)) {
			da�o=da�o-(da�o/5);
			System.out.println("Tu ataque es POCO EFICAZ");
		}
		pPK.cambiarVida(da�o);
	}
	
	protected abstract ListaAtaque crearListaAtaques();
	
	protected abstract boolean supereficaz(Pokemon pPK);
	
	protected abstract boolean pocoeficaz(Pokemon pPK);
	
	public void imprimirSoloInfoPK() {
		System.out.println("                           NOMBRE : " + this.nombre + ", VIDA : " + this.vida +", TIPO : " + this.tipo);
	}
	
	public int getVida() {
		return this.vida;
	}
}
