package org.pmoo.packproyecto;

public class CambiarDePokemonException extends Exception{

	public CambiarDePokemonException() {
		super();
	}
}
