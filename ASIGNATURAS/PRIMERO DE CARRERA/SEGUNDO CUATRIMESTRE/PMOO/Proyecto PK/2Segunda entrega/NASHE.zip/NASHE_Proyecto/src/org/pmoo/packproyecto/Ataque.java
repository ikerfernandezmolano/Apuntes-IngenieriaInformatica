package org.pmoo.packproyecto;

public class Ataque {
	private String nombre;
	private String tipo;
	private int da�o;
	private int usos;
	
	public Ataque(String pNombre,String pTipo,int pDa�o,int pUsos) {
		this.nombre=pNombre;
		this.tipo=pTipo;
		this.da�o=pDa�o;
		this.usos=pUsos;
	}
	
	public void imprimir(int pPosAtaqueEnLista) {
		System.out.println(pPosAtaqueEnLista + ".   NOMBRE : " + this.nombre + ", TIPO : " + this.tipo + ", DA�O : " + this.da�o + ", USOS : " + this.usos);
	}
	
	public int getDa�o() {
		return this.da�o;
	}
	
	public void disminuirUso() {
		this.usos--;
	} 
	
	public boolean ataqueGastado() {
		boolean gastado=false;
		if(this.usos<=0) {
			gastado=true;
		}
		return gastado;
	}
}
