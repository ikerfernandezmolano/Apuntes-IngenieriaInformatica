package org.pmoo.packproyecto;

public class UsarCuraException extends Exception{
	public UsarCuraException() {
		super();
	}
}
