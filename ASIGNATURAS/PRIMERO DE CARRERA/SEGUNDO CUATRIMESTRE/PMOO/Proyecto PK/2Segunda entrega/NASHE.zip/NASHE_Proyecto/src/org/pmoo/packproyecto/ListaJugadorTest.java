package org.pmoo.packproyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaJugadorTest {
	Agua pk1,pk4;
	Fuego pk2,pk5;
	Planta pk3,pk6;

	@Before
	public void setUp() throws Exception {
		 ListaJugador.getListaJugador().setNombres("Jugador1","Jugador2");
		 pk1=new Agua("PK1", "Agua", 10);
		 pk2=new Fuego("PK2", "Fuego", 3);
		 pk3=new Planta("PK3", "Planta", 11);
		 ListaJugador.getListaJugador().a�adirPokemon(1, pk1);
		 ListaJugador.getListaJugador().a�adirPokemon(1, pk2);
		 ListaJugador.getListaJugador().a�adirPokemon(1, pk3);
		 pk4=new Agua("PK4", "Agua", 10);
		 pk5=new Fuego("PK5", "Fuego", 3);
		 pk6=new Planta("PK6", "Planta", 11);
		 ListaJugador.getListaJugador().a�adirPokemon(2, pk4);
		 ListaJugador.getListaJugador().a�adirPokemon(2, pk5);
		 ListaJugador.getListaJugador().a�adirPokemon(2, pk6);
	}

	@After
	public void tearDown() throws Exception {
	}

	//public boolean listaVacia(int pPosJugador)
	@Test
	public void testListaVacia() {
		assertFalse(ListaJugador.getListaJugador().listaVacia(1));
		assertFalse(ListaJugador.getListaJugador().listaVacia(2));
	}

	@Test
	public void testA�adirPokemon() {
		try {
			assertEquals(ListaJugador.getListaJugador().sacarPokemon(1,1),pk1);
		} catch (Exception e) {}
	} 

	@Test
	public void testGetNombre() {
		assertEquals("Jugador1", ListaJugador.getListaJugador().getNombre(1));
		assertEquals("Jugador2", ListaJugador.getListaJugador().getNombre(2));
	}

	@Test
	public void testSacarPokemon() {
		try {
			assertNotNull(ListaJugador.getListaJugador().sacarPokemon(1, 1));
			
		} catch (Exception e) {}
		try {
			assertNotNull(ListaJugador.getListaJugador().sacarPokemon(2, 1));
		} catch (Exception e) {}
	}

	@Test
	public void testEliminarPokemon() {
		ListaJugador.getListaJugador().eliminarPokemon(1, pk2);
		Pokemon p;
		try {
			p = ListaJugador.getListaJugador().sacarPokemon(1, 2);
			assertNotEquals(p,pk2);
		} catch (Exception e) {}	
	}

	@Test
	public void testSetNombres() {
		assertEquals("Jugador1", ListaJugador.getListaJugador().getNombre(1));
		assertEquals("Jugador2", ListaJugador.getListaJugador().getNombre(2));
		assertNotEquals("Jug1", ListaJugador.getListaJugador().getNombre(1));
		assertNotEquals("Jug2", ListaJugador.getListaJugador().getNombre(2));
		}
}
